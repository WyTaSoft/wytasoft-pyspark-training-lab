# WytaSoft Training Academy – PySpark Project

## 📦 Overview
This project is designed as a full training framework for PySpark, including best practices for job structure, modular code design, and environment‑driven configuration. It uses Poetry for dependency management and a clean enterprise‑grade package layout.

---

## 📂 Project Structure
```
wytasoft_training_academy/
│
├── localrun/
│   ├── data/                     # Local sample datasets
│   └── application.yaml          # Config used for dev/local/prd runs
│
├── src/
│   └── main/
│       ├── py/
│       │   └── com/
│       │       └── wts/
│       │           └── training/
│       │               ├── app/
│       │               │   ├── common/       # Shared app helpers
│       │               │   ├── job/          # MainDriver & job entrypoints
│       │               │   │   └── MainDriver.py
│       │               │   ├── reader/       # App-level readers
│       │               │   ├── utility/      # App-level utils & constants
│       │               │   └── writer/       # Output writers
│       │               │
│       │               ├── mapping/          # Mapping tables, schema definitions
│       │               ├── reader/           # Framework-level readers
│       │               ├── utility/          # General utilities
│       │               ├── writer/           # Framework-level writers
│       │               └── sessionmanager/   # SparkSessionManager
│       │
│       └── resources/                      # Optional assets/resources
│
└── README.md

```

---

## ⚙️ Installation (Poetry)

### 1. Install Poetry
```
pip install poetry
```

### 2. Install dependencies
```
poetry install
```

### 3. (Optional) Enter the virtual environment
```
poetry shell
```

---

## 🚀 Running the PySpark Job
Jobs are executed using `python -m` to reference the module path.

### **Run the main training job:**
```
poetry run python -m com.wts.training.app.job.MainDriver prd localrun/application.yaml
```

Where:
- `prd` = environment (dev/test/prd)
- `localrun/application.yaml` = path to config

---

## 🧩 Configuration (YAML)
Example of a simple configuration file:
```
training_app:
  clients:
    dev: "localrun/data/clients_dev.csv"
    prd: "localrun/data/clients_prd.csv"

  output_path: "localrun/output/"
```
You can access values inside your application as:
```
config["training_app"]["clients"][env]
```

---

## 🏗 Architecture Components

### 🔹 SparkSessionManager
Central place to configure and create Spark sessions.

### 🔹 PrimaryReader
Reads datasets based on the configured environment.

### 🔹 PrimaryRunner
Handles business logic, transformation, and enrichment.

### 🔹 PrimaryWriter
Writes results to the configured output storage.

---

## ➕ Adding a New Job
1. Create a file inside:
```
src/main/py/com/wts/training/app/job/
```
2. Add your main job logic.
3. Run it using:
```
poetry run python -m com.wts.training.app.job.NewDriver dev localrun/application.yaml
```

---

## 🧪 Local Development Tips
You can test Spark manually:
```
poetry run python
>>> from com.wts.training.sessionmanager.SparkSessionManager import SparkSessionManager
>>> spark = SparkSessionManager.fetch_spark_session("test")
>>> spark.range(5).show()
```

---

## 📚 Notes
- Windows users may see harmless Spark temp cleanup warnings.
- You can disable cleanup via:
```
.config("spark.cleanup.enabled", "false")
```

---


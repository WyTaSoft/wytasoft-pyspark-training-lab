import logging
from pyspark.sql import DataFrame, SparkSession

from src.main.py.com.wts.training.app.mapping.PrimaryMapper import PrimaryMapper
from src.main.py.com.wts.training.app.reader.PrimaryReader import PrimaryReader
from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants


class PrimaryRunner:
    """
    Class responsible for orchestrating the data processing pipeline in a Spark application.
    It utilizes instances of `PrimaryReader` for data retrieval and `PrimaryMapper` for data transformation.
    This runner triggers the entire process that fetches, maps, and enriches datasets using predefined logic.

    :param fetch_source: An instance of `PrimaryReader` to access methods for fetching DataFrames based on predefined schemas.
    :param spark_session: SparkSession to provide the required context for DataFrame operations.
    """

    def __init__(self, fetch_source: PrimaryReader, spark_session: SparkSession):
        """
        Initializes the PrimaryRunner with a data reader (fetch_source) and a Spark session.

        :param fetch_source: PrimaryReader object used to fetch the datasets.
        :param spark_session: Active Spark session used for processing.
        """
        self.fetch_source = fetch_source
        self.spark_session = spark_session
        self.log = logging.getLogger(self.__class__.__name__)

    def run_primary_runner(self) -> DataFrame:
        """
        Executes the data processing tasks by coordinating the fetching of source data through `PrimaryReader`
        and applying transformations via `PrimaryMapper`.

        This method fetches client and order data, then processes it using business logic defined in `PrimaryMapper`
        to produce an enriched DataFrame that combines elements of both datasets.

        :return: DataFrame containing enriched data as a result of applying transformations on source data.
        """
        self.log.info("Starting data processing...")

        try:
            # Fetch client and order DataFrames using the provided PrimaryReader.
            clients_df = self.fetch_source.get_dataframe(PrimaryConstants.CLIENTS)
            orders_df = self.fetch_source.get_dataframe(PrimaryConstants.ORDERS)

            # Instantiate PrimaryMapper with the required DataFrames.
            primary_mapper = PrimaryMapper(clients_df, orders_df, self.spark_session)

            # Enrich and map data using the PrimaryMapper.
            enriched_df = primary_mapper.enrich_dataframe()

            self.log.info("Data processing completed successfully.")
            return enriched_df

        except Exception as e:
            # Log any exception that occurs during data processing.
            self.log.error(f"Error during data processing: {e}", exc_info=True)
            raise

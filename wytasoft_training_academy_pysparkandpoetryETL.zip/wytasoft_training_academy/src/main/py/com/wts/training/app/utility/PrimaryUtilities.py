import logging
from pyspark.sql import SparkSession, DataFrame, Column
from pyspark.sql.functions import lit, col, regexp_extract, max as spark_max
from pyspark.sql.types import StructType
from datetime import datetime
import yaml
from pyspark.sql.utils import AnalysisException
import re
import datetime

from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants


class PrimaryUtilities:
  """
  Utility class providing methods for interacting with HDFS, reading and writing DataFrames,
  and handling date conversions, tailored for Spark applications.
  """
  log = logging.getLogger(__name__)

  @staticmethod
  def get_max_partition(path: str, column_partitioned: str = "date", spark: SparkSession = None) -> str:
    """
    Fetches the most recent partition based on a date column from a specified HDFS path.

    :param path: The HDFS directory to scan.
    :param column_partitioned: The partition column, defaulted to 'date'.
    :param spark: The Spark session.
    :return: The most recent partition date as a string, or a far-future date if no partitions exist.
    """
    try:
      fs = spark._jvm.org.apache.hadoop.fs.FileSystem.get(spark._jsc.hadoopConfiguration())
      list_of_insert_dates = fs.listStatus(spark._jvm.org.apache.hadoop.fs.Path(path))
      partition_folders = [str(folder.getPath()) for folder in list_of_insert_dates if folder.isDirectory()]

      filtered_folders = [folder.split(f"{column_partitioned}=")[1] for folder in partition_folders if f"{column_partitioned}=" in folder]
      if filtered_folders:
        dates = [PrimaryUtilities.convert_string_to_date(date_str, "%Y-%m-%d") for date_str in filtered_folders]
        max_date = PrimaryUtilities.date_to_str_and_reformat(max(dates), "%Y-%m-%d")
        PrimaryUtilities.log.info(f"Max partition by {column_partitioned}: {max_date}")
        return max_date
      else:
        PrimaryUtilities.log.info(f"No partitions by {column_partitioned} in {path}")
        return "2999-01-01"
    except Exception as e:
      PrimaryUtilities.log.error(f"Error while getting max partition: {e}")
      raise ValueError("Error fetching partition")

  @staticmethod
  def read_dataframe(source_name: str, schema: StructType, spark_session: SparkSession, env: str, config: dict, file_format: str = "parquet", options: dict = None,  is_condition: bool = False, condition: Column = None) -> DataFrame:
    """
    Reads a DataFrame from a specified source path using a predefined schema.

    :param source_name: The identifier for the data source to load.
    :param schema: The schema to apply to the DataFrame.
    :param spark_session: SparkSession to handle DataFrame operations.
    :param env: Environment used for building the data path.
    :param config: Additional configuration settings.
    :param is_condition: Boolean indicating if a condition should be applied.
    :param condition: The conditional filter to apply, if any.
    :return: DataFrame loaded from the specified path.
    """
    PrimaryUtilities.log.info("Reading file to create DataFrame...")
    effective_condition = condition if is_condition else lit(True)

    table_name = source_name.lower()
    input_path = config[PrimaryConstants.APPLICATION_NAME][table_name][env]

#    if source_name == PrimaryConstants.ORDERS:
#      partition_value = PrimaryUtilities.get_max_partition(f"{input_path}{table_name}/", spark_session=spark_session)
#      table_name = f"orders/date={partition_value}"

    PrimaryUtilities.log.info(f"Loading {source_name} from {input_path}{table_name}")

    # Use spark_session.read.format to dynamically set the file format
    reader = spark_session.read.format(file_format).schema(schema)

    # Apply additional read options if provided
    if options:
      for key, value in options.items():
        reader = reader.option(key, value)

    dataframe = reader.load(f"{input_path}{table_name}/").where(effective_condition)

    return dataframe

  @staticmethod
  def convert_string_to_date(s: str, format_type: str) -> datetime:
    """
    Converts a string to a Date object using the specified date format.
    """
    return datetime.strptime(s, format_type)

  @staticmethod
  def date_to_str_and_reformat(date: datetime, format_str: str) -> str:
    """
    Reformats a Date object to a string using the specified date format.
    """
    return date.strftime(format_str)

  @staticmethod
  def write_dataframe(dataframe: DataFrame, mode: str, num_partition: int, env: str, output_name: str, config: dict):
    """
    Writes a DataFrame to a specified path with a given mode and number of partitions.

    :param dataframe: The DataFrame to write.
    :param mode: The save mode (e.g., "overwrite", "append").
    :param num_partition: The number of partitions to use when writing the DataFrame.
    :param env: Environment string for the write operation.
    """
    dataframe.show()
    PrimaryUtilities.log.info(f"Writing DataFrame (mode: {mode}, num partitions: {num_partition})...")

    table_name = output_name.lower()
    output_path = config[PrimaryConstants.APPLICATION_NAME][table_name][env]


    #dataframe.write.mode("overwrite").parquet(output_path)
    dataframe.write.mode("overwrite").partitionBy("year", "month").parquet(output_path)

    PrimaryUtilities.log.info("Write operation completed.")

  @staticmethod
  def read_yaml_config(file_path):
    with open(file_path, 'r') as stream:
      try:
        config = yaml.safe_load(stream)
        return config
      except yaml.YAMLError as exc:
        print(exc)

def get_max_partition(path: str, column_partitioned: str = "date", spark: SparkSession = None):
  """
  Extract max partition from folder structure like:
      path/date=2023-01-01
  or path/year=2023/month=01/day=05, depending on column_partitioned.
  """
  if spark is None:
    raise Exception("SparkSession is required")

  hadoop_conf = spark.sparkContext._jsc.hadoopConfiguration()
  fs = spark._jvm.org.apache.hadoop.fs.FileSystem.get(hadoop_conf)
  jpath = spark._jvm.org.apache.hadoop.fs.Path(path)

  try:
    # List directories in the given path
    statuses = fs.listStatus(jpath)
    folders = [str(s.getPath()) for s in statuses if s.isDirectory()]

    # Filter only folders that contain the partition name (like "date=", "year=", "month=")
    partition_folders = [f for f in folders if f"{column_partitioned}=" in f]

    if len(partition_folders) == 0:
      print(f"**** no partition by {column_partitioned} in {path} ****")
      return "2999-01-01"

    # Extract the partition value after "columnPartitioned="
    # Example: "/path/date=2023-01-05" → "2023-01-05"
    extracted = [
      re.split(f"{column_partitioned}=", f)[1].replace("/", "")
      for f in partition_folders
    ]

    if len(extracted) == 1:
      print(f"**** max {column_partitioned} = {extracted[0]} ****")
      return extracted[0]

    # Convert strings to date objects
    dates = [
      datetime.datetime.strptime(d, "%Y-%m-%d").date()
      for d in extracted
    ]

    # Max date
    max_date = max(dates)
    print(f"**** max {column_partitioned} = {max_date} ****")

    return str(max_date)

  except Exception as e:
    print("Fatal Exception: Check Src-View Data")
    raise e

def get_max_year_month(path: str, spark: SparkSession):
  """
  Returns the max (year, month) from a directory structured like:
      path/year=YYYY/month=MM

  Does NOT read files — uses Hadoop FileSystem metadata only.
  """

  hconf = spark.sparkContext._jsc.hadoopConfiguration()
  fs = spark._jvm.org.apache.hadoop.fs.FileSystem.get(hconf)
  jpath = spark._jvm.org.apache.hadoop.fs.Path(path)

  # ---------- 1. LIST year=YYYY folders ----------
  year_dirs = [
    str(status.getPath())
    for status in fs.listStatus(jpath)
    if status.isDirectory() and "year=" in str(status.getPath())
  ]

  if not year_dirs:
    raise Exception(f"No year partitions found under: {path}")

  # Extract numeric year
  years = [
    int(re.split("year=", y)[1].replace("/", "")) for y in year_dirs
  ]
  max_year = max(years)

  # ---------- 2. LIST month=MM folders only inside max year ----------
  year_path = spark._jvm.org.apache.hadoop.fs.Path(f"{path}/year={max_year}")

  month_dirs = [
    str(status.getPath())
    for status in fs.listStatus(year_path)
    if status.isDirectory() and "month=" in str(status.getPath())
  ]

  if not month_dirs:
    raise Exception(f"No month partitions found under: {path}/year={max_year}")

  # Extract numeric month
  months = [
    int(re.split("month=", m)[1].replace("/", "")) for m in month_dirs
  ]
  max_month = max(months)

  return max_year, max_month
from pyspark.sql import DataFrame, SparkSession
from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants
from src.main.py.com.wts.training.app.utility.PrimaryUtilities import PrimaryUtilities  # Corrected import
from src.main.py.com.wts.training.app.utility.SchemaSelector import SchemaSelector


class PrimaryReader(SchemaSelector):
  """
  A class responsible for fetching DataFrames for different entities such as clients and orders
  within a Spark application. This reader simplifies data access by pre-loading DataFrames based
  on specified schemas and ensures efficient data handling by leveraging Spark's lazy initialization.

  :param spark_session: SparkSession that provides the context for DataFrame operations.
  :param env: Environment string that helps determine the run-time environment for data path resolutions.
  :param config: Config object to fetch application-specific settings.
  """

  def __init__(self, spark_session: SparkSession, env: str, config: dict):
    super().__init__()
    self.spark_session = spark_session
    self.env = env
    self.config = config
    self._clients_df = None
    self._orders_df = None

  @property
  def clients(self) -> DataFrame:
    """
    Lazy initialization of DataFrame for clients using predefined schema from SchemaSelector.
    """
    if self._clients_df is None:
      self._clients_df = PrimaryUtilities.read_dataframe(
        PrimaryConstants.CLIENTS,
        self.clients_schema,
        spark_session=self.spark_session,
        env=self.env,
        config=self.config,
        file_format="csv",
        options={
          "header": "true",      # Indicates the CSV file has a header
          "delimiter": ","       # Specify the delimiter (e.g., comma for CSV)
        }
      )
      return self._clients_df


  @property
  def orders(self) -> DataFrame:
    """
    Lazy initialization of DataFrame for orders using predefined schema from SchemaSelector.
    """
    if self._orders_df is None:
      self._orders_df = PrimaryUtilities.read_dataframe(
        PrimaryConstants.ORDERS,
        self.orders_schema,
        spark_session=self.spark_session,
        env=self.env,
        config=self.config,
        file_format="csv",
        options={
          "header": "true",      # Indicates the CSV file has a header
          "delimiter": ","       # Specify the delimiter (e.g., comma for CSV)
        }
      )
    return self._orders_df

  def get_dataframe(self, input_str: str) -> DataFrame:
    """
    Retrieves the DataFrame based on a specified input string that identifies the dataset.

    :param input_str: A string identifier for the dataset, expected values are "CLIENTS" or "ORDERS".
    :return: DataFrame corresponding to the input identifier.
    :raises ValueError: if the input does not match expected dataset identifiers.
    """
    input_str = input_str.upper()
    if input_str == "CLIENTS":
      return self.clients
    elif input_str == "ORDERS":
      return self.orders
    else:
      raise ValueError(f"Invalid input {input_str}. Expected 'CLIENTS' or 'ORDERS'.")

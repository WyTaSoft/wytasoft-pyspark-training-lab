from pyspark.sql import SparkSession


class SparkSessionManager:
    """
  Singleton class to manage Spark Session creation.

  This design ensures that only one instance of SparkSession is used throughout the application.
  The SparkSession is configured with enhanced settings for performance and efficiency.

  :author: Mehdi TAJMOUATI
  :note: Big Data/Cloud Trainer at WyTaSoft.
         For queries, training, or further information, contact mehdi.tajmouati@wytasoft.com.
  """

    @staticmethod
    def fetch_spark_session(app_name: str) -> SparkSession:
        """
    Fetches or creates a SparkSession with specified application name and configuration settings.

    :param app_name: The name of the application. This name will be displayed in the Spark UI.
    :return: An instance of SparkSession tailored for the application, ensuring optimal performance.
    """

        return (
            SparkSession.builder
            .appName(app_name)  # Sets the name for the application in the Spark UI.
            .config("spark.serializer",
                    "org.apache.spark.serializer.KryoSerializer")  # Optimizes object serialization for better performance.
            .config("spark.sql.tungsten.enabled",
                    "true")  # Activates Project Tungsten for improved memory management and execution efficiency.
            .config("spark.rdd.compress", "true")  # Enables compression of RDDs, reducing memory footprint.
            .config("spark.io.compression.codec",
                    "snappy")  # Applies Snappy compression to internal data transfers, enhancing IO efficiency.
            .config("spark.sql.broadcastTimeout",
                    "1200")  # Extends the timeout for broadcast operations to prevent failures in larger environments.
            .config("spark.eventLog.enabled",
                    "true")  # Enables detailed event logging, useful for debugging and performance tuning.
            .config("spark.local.dir", "C:/tmp/spark")
            .enableHiveSupport()  # Integrates Hive support, enabling SQL-like manipulation of stored data.
            .getOrCreate()
        # Ensures a single instance of SparkSession, reusing the existing session or creating a new one if needed.
        )

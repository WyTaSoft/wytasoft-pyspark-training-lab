from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import broadcast
from src.main.py.com.wts.training.app.mapping.PrimaryView import PrimaryView


class PrimaryMapper:
  """
  A class responsible for mapping and enriching DataFrames through SQL transformations.
  This class takes predefined DataFrames of clients and orders, and applies SQL logic
  to enrich and transform the data, making it ready for further processing or analytics.

  The class uses Spark SQL's capabilities to execute complex queries and manipulations
  by leveraging temporary views created from the input DataFrames.

  :param clients: DataFrame containing client data.
  :param orders: DataFrame containing order data.
  :param spark_session: SparkSession that provides the necessary context for DataFrame operations.
  :author: Mehdi TAJMOUATI
  :note: Ensures that all transformations are performed within Spark's optimized SQL engine, providing efficient data handling.
  :see: https://www.wytasoft.com/wytasoft-group/ for more information on data processing courses.
  """

  def __init__(self, clients: DataFrame, orders: DataFrame, spark_session: SparkSession):
    """
    Initializes the PrimaryMapper with clients and orders DataFrames and the SparkSession.

    :param clients: DataFrame containing the client data.
    :param orders: DataFrame containing the order data.
    :param spark_session: The active Spark session.
    """
    self.clients = clients
    self.orders = orders
    self.spark_session = spark_session

  def enrich_dataframe(self) -> DataFrame:
    """
    Enriches the input DataFrames by applying a SQL transformation.
    This method creates temporary views for the clients and orders DataFrames and then
    executes a SQL query to join and enrich the data based on business logic defined in `PrimaryView.get_client_order_sql_string`.

    The resulting DataFrame combines and enhances the data from both views, which can then be used
    for advanced analytics or reporting.

    :return: DataFrame resulting from the SQL query, containing enriched data.
    """
    # Registering DataFrames as temporary views in the Spark SQL catalog
    self.clients.createOrReplaceTempView("clients_view")
    self.orders.createOrReplaceTempView("orders_view")

    # Executing a predefined SQL query to join and enrich the data
    # Assuming the SQL query is available in a separate module, e.g., PrimaryView
    query = PrimaryView.get_client_order_sql_string()

    # Return the enriched DataFrame from the SQL query
    return self.spark_session.sql(query)



  def enrich_dataframe_2(self):
    c = self.clients.alias("c")
    o = self.orders.alias("o")

    enriched = (
      o.join(
        broadcast(c),
        on="clientId",
        how="left"
      )
      .select(
        c.clientId,
        c.name,
        c.location,
        o.orderId,
        o.amount,
        o.date
      )
    )

    return enriched
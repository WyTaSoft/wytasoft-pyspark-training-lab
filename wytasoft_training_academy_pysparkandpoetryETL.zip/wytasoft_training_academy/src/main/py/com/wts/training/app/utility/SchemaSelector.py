from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, DateType

class SchemaSelector:
  """
  A class for defining and managing schemas for different data entities within the application.
  This ensures that all data manipulations use consistent and structured data types across the application.

  Provides pre-defined schemas for entities like clients and orders,
  which can be reused throughout the Spark application to maintain uniformity in data handling.

  ==Overview==
  - clients_schema: Defines schema for client data including fields like clientId, name, and location.
  - orders_schema: Defines schema for order data including fields like orderId, clientId, amount, and date.

  :note: This schema definition module is designed and maintained by Mehdi TAJMOUATI, a Big Data/Cloud Trainer.
  """

  # Schema for clients data
  clients_schema = StructType([
    StructField("clientId", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("location", StringType(), True)
  ])

  # Schema for orders data
  orders_schema = StructType([
    StructField("orderId", IntegerType(), True),
    StructField("clientId", IntegerType(), True),
    StructField("amount", DoubleType(), True),
    StructField("date", DateType(), True)
  ])

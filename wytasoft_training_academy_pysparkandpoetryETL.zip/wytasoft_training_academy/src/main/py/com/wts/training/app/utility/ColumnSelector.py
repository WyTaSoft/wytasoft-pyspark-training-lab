from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants


class ColumnSelector:
    """
    Class to manage the selection of columns for various tables within the Spark application.
    This allows for centralized control over which columns are retrieved for specific datasets,
    ensuring consistency across different parts of the application when accessing data.

    The class provides a method to retrieve a list of column names based on the table name,
    simplifying the process of querying data with Spark SQL or DataFrame operations.

    :author: Mehdi TAJMOUATI
    :note: For further inquiries or detailed explanations of column selection strategy,
           contact mehdi.tajmouati@wytasoft.com
    """

    @staticmethod
    def get_column_sequence(table_name: str) -> list:
        """
        Retrieves a list of column names for specified tables.
        The columns selected are essential for respective tables to ensure that only relevant data is processed.

        :param table_name: The name of the table for which columns need to be fetched.
                           The table name should match one of the constants defined in `PrimaryConstants`.
        :return: A list of column names corresponding to the table's requirements.
        """
        table_name = table_name.lower()

        if table_name == PrimaryConstants.ORDERS:
            return [
                "clientid",  # Unique identifier for the client.
                "name",      # Name of the client.
                "location"   # Geographical location of the client.
            ]

        elif table_name == PrimaryConstants.CLIENTS:
            return [
                "orderid",   # Unique identifier for the order.
                "clientid",  # Client identifier linking to the client's details.
                "amount",    # Monetary value of the order.
                "date"       # Date the order was placed.
            ]

        else:
            raise ValueError(f"Invalid table name: {table_name}. Expected 'ORDERS' or 'CLIENTS'.")

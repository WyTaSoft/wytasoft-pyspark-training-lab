import logging

from src.main.py.com.wts.training.app.utility.PrimaryUtilities import PrimaryUtilities
from src.main.py.com.wts.training.app.common.PrimaryRunner import PrimaryRunner
from src.main.py.com.wts.training.app.reader.PrimaryReader import PrimaryReader
from src.main.py.com.wts.training.app.writer.PrimaryWriter import PrimaryWriter
from src.main.py.com.wts.training.app.utility.PrimaryConstants import PrimaryConstants

from src.main.py.com.wts.training.sessionmanager.SparkSessionManager import SparkSessionManager
from pyspark.sql.functions import year, month, to_date, col

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main(env: str, absolute_config_path: str):
    """
  Main entry point for the PySpark job.

  :param env: Environment name, e.g., "dev", "test", "prod"
  :param absolute_config_path: Path to the configuration file
  """

    # Step 1: Initialize Spark Session using the SparkSessionManager
    spark_session = SparkSessionManager.fetch_spark_session(PrimaryConstants.APPLICATION_NAME)

    # Step 2: Read configuration file
    # Path to the YAML configuration file
    #yaml_file_path = '/wytasoft_training_academy/resources/application.yaml'

    # Load the configuration
    config = PrimaryUtilities.read_yaml_config(absolute_config_path)

    input_path = config[PrimaryConstants.APPLICATION_NAME]["clients"][env]

    logger.info(input_path)

    logger.info("\n\n**** training job has started ... ****\n\n")

    # Step 3: Initialize PrimaryReader to read data
    primary_reader = PrimaryReader(spark_session=spark_session, env=env, config=config)

    # Step 4: Initialize PrimaryRunner to run data processing
    primary_runner = PrimaryRunner(fetch_source=primary_reader, spark_session=spark_session)
    enriched_data = primary_runner.run_primary_runner()

    # Step 5: Initialize PrimaryWriter to write data
    primary_writer = PrimaryWriter(env=env)
#    primary_writer.write(enriched_data, PrimaryConstants.MODE_OVERWRITE, 2, "orders_by_date", config)

    orders_df = primary_reader.get_dataframe(PrimaryConstants.ORDERS)

    orders_df_to_par = (
        orders_df.withColumn("date", to_date(col("date")))
        .withColumn("year", year(col("date")))
        .withColumn("month", month(col("date")))
    )

    primary_writer.write(orders_df_to_par, PrimaryConstants.MODE_OVERWRITE, 1, "orders_by_date", config)

    """
    # . Verify by reading the data back
    try:
        written_data = spark_session.read.parquet("/prd/project/datalake/clients_orders/")
        print(f"Data was successfully written and contains {written_data.count()} records.")
        written_data.show()  # Display first 5 rows to verify
    except Exception as e:
        print(f"Failed to read data from /prd/project/datalake/clients_orders/. Error: {str(e)}")
    """
    # Step 6: Close Spark session
    spark_session.stop()


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        logger.error("Usage: main.py <env> <absolute_config_path>")
        sys.exit(1)

    # Pass environment and configuration path from the command-line arguments
    main(sys.argv[1], sys.argv[2])

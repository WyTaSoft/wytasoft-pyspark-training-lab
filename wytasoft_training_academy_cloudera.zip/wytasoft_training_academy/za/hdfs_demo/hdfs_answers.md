# HDFS Training – Answers

## Exercise 1 — Explore HDFS via CLI
1. `hdfs dfs -ls /`
2. 
```
hdfs dfs -mkdir /training
hdfs dfs -mkdir /training/raw
hdfs dfs -mkdir /training/processed
```
3. `hdfs dfs -ls /training`

## Exercise 2 — Importer un fichier local dans HDFS
1. `echo "Bonjour HDFS" > demo.txt`
2. `hdfs dfs -put demo.txt /training/raw/`
3. `hdfs dfs -ls /training/raw`

## Exercise 3 — Lire et télécharger un fichier HDFS
1. `hdfs dfs -cat /training/raw/demo.txt`
2. `hdfs dfs -get /training/raw/demo.txt demo_local.txt`

## Exercise 4 — Copier, déplacer et renommer dans HDFS
1. `hdfs dfs -cp /training/raw/demo.txt /training/processed/demo_copy.txt`
2. `hdfs dfs -mv /training/raw/demo.txt /training/processed/demo_moved.txt`
3. `hdfs dfs -ls /training/processed`

## Exercise 5 — Vérifier les métadonnées et la réplication
1. `hdfs dfs -stat %r /training/processed/demo_copy.txt`
2. `hdfs dfs -setrep 1 /training/processed/demo_copy.txt`
3. `hdfs dfs -stat %r /training/processed/demo_copy.txt`

## Exercise 6 — Inspecter les blocs HDFS
1. `hdfs fsck /training/processed/demo_copy.txt -files -blocks -locations`
2. Same command outputs block locations.

## Exercise 7 — Append à un fichier HDFS
1. `echo "Nouvelle ligne ajoutée" >> demo.txt`
2. `hdfs dfs -appendToFile demo.txt /training/processed/demo_copy.txt`
3. `hdfs dfs -cat /training/processed/demo_copy.txt`

## Exercise 8 — Pipeline de fichiers (mini-ETL)
1. `hdfs dfs -mkdir -p /etl/input /etl/staging /etl/output`
2. 
```
cat > customers.csv <<EOF
id,name,country
1,Alice,FR
2,Bob,US
3,Mehdi,MA
EOF

hdfs dfs -put customers.csv /etl/input/
```
3. `hdfs dfs -mv /etl/input/customers.csv /etl/staging/`
4. `hdfs dfs -cp /etl/staging/customers.csv /etl/output/`

## Exercise 9 — Permissions et sécurité HDFS
1. `hdfs dfs -chmod 700 /etl`
2. `hdfs dfs -chmod 755 /etl/output`
3. `hdfs dfs -chown hduser:supergroup /etl`

## Exercise 10 — WordCount sur HDFS
1. 
```
hadoop jar /opt/hadoop*/share/hadoop/mapreduce/hadoop-mapreduce-examples*.jar wordcount     /etl/output /wc_out
```
2. Output directory is created at `/wc_out`
3. `hdfs dfs -cat /wc_out/part-r-00000`

## Devoir final — Mini Data Lake
1. `hdfs dfs -mkdir -p /datalake/raw /datalake/clean /datalake/agg`
2. 
```
hdfs dfs -put file1.csv /datalake/raw/
hdfs dfs -put file2.csv /datalake/raw/
```
3. `hdfs dfs -mv /datalake/raw/*.csv /datalake/clean/`
4. `hdfs dfs -cp /datalake/clean/*.csv /datalake/agg/`
5. `hdfs fsck /datalake/agg -files -blocks -locations`

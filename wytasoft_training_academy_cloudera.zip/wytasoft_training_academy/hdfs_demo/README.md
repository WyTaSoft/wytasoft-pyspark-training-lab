# HDFS Demo – WyTaSoft Training Academy

## Start Hadoop Cluster
```
docker-compose up -d
```

```
docker-compose down -v
docker-compose up -d
```


## Access NameNode UI
http://localhost:9870

## Demo Commands
```
docker exec -it namenode bash
hdfs dfs -mkdir /demo
echo "Hello HDFS!" > demo.txt
hdfs dfs -put demo.txt /demo/
hdfs dfs -ls /demo
```

# HDFS Training – Questions (Without Answers)

## Exercise 1 — Explore HDFS via CLI
1. Quelle commande permet de lister le contenu de la racine HDFS (`/`) ?
2. Crée trois répertoires : `/training`, `/training/raw`, `/training/processed`.
3. Vérifie qu'ils ont bien été créés.

## Exercise 2 — Importer un fichier local dans HDFS
1. Crée un fichier local nommé `demo.txt` contenant le texte : "Bonjour HDFS".
2. Charge ce fichier dans HDFS sous `/training/raw`.
3. Liste les fichiers dans `/training/raw`.

## Exercise 3 — Lire et télécharger un fichier HDFS
1. Affiche le contenu de `/training/raw/demo.txt`.
2. Télécharge ce fichier en local sous le nom `demo_local.txt`.

## Exercise 4 — Copier, déplacer et renommer dans HDFS
1. Copie `/training/raw/demo.txt` dans `/training/processed/demo_copy.txt`.
2. Déplace le fichier original dans `/training/processed/demo_moved.txt`.
3. Liste le contenu de `/training/processed`.

## Exercise 5 — Vérifier les métadonnées et la réplication
1. Quel est le facteur de réplication du fichier `demo_copy.txt` ?
2. Change son facteur de réplication à 1.
3. Vérifie la mise à jour du facteur de réplication.

## Exercise 6 — Inspecter les blocs HDFS
1. Quels blocs composent le fichier `demo_copy.txt` ?
2. Sur quels DataNodes sont stockés ces blocs ?

## Exercise 7 — Append à un fichier HDFS
1. Ajoute une ligne au fichier local `demo.txt`.
2. Ajoute cette ligne au fichier HDFS `/training/processed/demo_copy.txt`.
3. Affiche le fichier mis à jour.

## Exercise 8 — Pipeline de fichiers (mini-ETL)
1. Crée les répertoires `/etl/input`, `/etl/staging`, `/etl/output`.
2. Charge un fichier CSV d’exemple dans `/etl/input`.
3. Déplace ce fichier dans `/etl/staging`.
4. Copie ce fichier dans `/etl/output`.

## Exercise 9 — Permissions et sécurité HDFS
1. Mets les permissions 700 sur `/etl`.
2. Mets les permissions 755 sur `/etl/output`.
3. Change le propriétaire de `/etl`.

## Exercise 10 — WordCount sur HDFS
1. Lance un job WordCount sur le fichier `/etl/output/customers.csv`.
2. Stocke le résultat dans `/wc_out`.
3. Affiche le contenu du résultat.

## Devoir final — Mini Data Lake
1. Crée une structure Data Lake : `raw`, `clean`, `agg`.
2. Importe deux fichiers CSV dans `raw`.
3. Déplace les fichiers de `raw` vers `clean`.
4. Copie `clean` vers `agg`.
5. Vérifie les blocs et la réplication des fichiers.

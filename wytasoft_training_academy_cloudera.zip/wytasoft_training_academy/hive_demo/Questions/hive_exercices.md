
# 📘 Exercices Hive — Formation Big Data  
Ensemble d'exercices pratiques pour apprendre Hive : bases de données, tables, requêtes SQL, partitions, vues matérialisées, formats ORC/Parquet, et ETL.

---

## 📝 Exercice 1 — Découvrir la base de données Hive
1. Afficher la liste des bases de données existantes.  
2. Créer une base de données nommée `formation_hive`.  
3. Basculer sur cette base de données.  
4. Vérifier qu’elle est bien active.

---

## 📝 Exercice 2 — Créer une table EXTERNAL
Données : un fichier CSV `clients.csv` contenant :

```
id,name,country,age
1,Alice,FR,29
2,Bob,US,41
3,Mehdi,MA,35
4,Sara,FR,23
5,John,UK,52
```

1. Créer un dossier HDFS `/data/clients`.  
2. Charger le fichier CSV dans ce dossier.  
3. Créer une table EXTERNAL `clients` avec :  
   - 4 colonnes (id, name, country, age)  
   - séparateur `,`  
   - stockage TEXTFILE  
   - LOCATION `/data/clients`  
4. Vérifier le contenu de la table.

---

## 📝 Exercice 3 — Créer une table MANAGED
Données : fichier `transactions.csv`

1. Créer une table MANAGED `transactions` avec les colonnes :
   - txn_id  
   - customer_id  
   - amount  
   - category  
   - date  
2. Charger les données dans la table.  
3. Afficher les 5 premières lignes.

---

## 📝 Exercice 4 — Requêtes SQL de base
1. Compter le nombre total de clients.  
2. Donner la liste des pays distincts.  
3. Trouver l'âge moyen des clients par pays.  
4. Trouver les transactions dont le montant dépasse 100.  

---

## 📝 Exercice 5 — Faire un JOIN
1. Faire un JOIN entre `clients` et `transactions`.  
2. Afficher : nom, pays, catégorie d'achat, montant, date.  
3. Trier par montant décroissant.  

---

## 📝 Exercice 6 — Table partitionnée
1. Créer une table partitionnée `tx_part` partitionnée par (`year`, `month`).  
2. Ajouter une partition `2024 / 02`.  
3. Placer les données de février 2024 dans cette partition.  
4. Vérifier que la partition est bien détectée par Hive.  

---

## 📝 Exercice 7 — Table ORC optimisée
1. Créer une table ORC `clients_orc`.  
2. Y insérer les données depuis la table `clients`.  
3. Comparer la taille ou le temps d'exécution de :
   - `SELECT COUNT(*) FROM clients;`
   - `SELECT COUNT(*) FROM clients_orc;`

---

## 📝 Exercice 8 — Vues matérialisées
1. Créer une vue matérialisée `mv_stats_pays` calculant :
   - nb de clients par pays  
   - âge moyen  
2. Afficher le contenu de la vue.  

---

## 📝 Exercice 9 — Pipeline ETL simple
1. Créer une table brute `raw_tx` (1 colonne `line`).  
2. Charger le CSV brut dans cette table.  
3. Créer une table propre `clean_tx` avec les champs extraits via `split()`.  
4. Insérer les données nettoyées dans `clean_tx`.  
5. Vérifier la qualité des données.  

---

## 📝 Exercice 10 — Analyse avancée (optionnel)
1. Trouver la transaction la plus élevée par pays.  
2. Calculer le montant cumulé des achats par client (window function).  
3. Trouver les 3 clients qui dépensent le plus.  

---

## 🎓 Exercice Final — Mini Data Warehouse Hive
Créer une architecture Data Lake :

```
raw/
clean/
agg/
```

1. Importer deux fichiers CSV dans `raw`.  
2. Transformer et déplacer les résultats vers `clean`.  
3. Créer des tables ORC dans `agg`.  
4. Faire une agrégation par pays (nombre de clients, montant total, montant moyen).  
5. Générer une vue finale `vw_dashboard`.  

---

Bonne formation ! 🚀

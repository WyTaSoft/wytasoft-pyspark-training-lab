# 🐝 Hive Demo — Lightweight Hive Training Environment

This folder provides a **lightweight Hive environment** using Docker and the official `apache/hive:3.1.3` image.
It is optimized for training sessions:

✅ No Hadoop required  
✅ Starts in a few seconds  
✅ Uses SQLite metastore  
✅ Supports HiveServer2 + Beeline  
✅ Perfect for SQL, ETL & table modeling demos  

---

## 📁 Folder Structure

```
hive_demo/
│
├── docker-compose.yml     # Lightweight Hive environment
├── README.md              # This file
├── data/                  # (Optional) CSV files for demos
└── sql/                   # (Optional) SQL scripts for demos
```

---

## 🚀 Starting the Hive Environment

From inside the folder:

```bash
docker-compose up -d
```

Check if the container is running:

```bash
docker ps
```

You should see a container named **hive** exposing port **10000**.

```bash
docker exec -it hive bash
```


---

## 🐝 Connecting to Hive (Beeline)

```bash
mkdir hive_demo
mkdir hive_demo/warehouse
chmod -R 777 hive_demo/warehouse
```


Enter the Hive container:

Launch Beeline:

```bash
beeline -u jdbc:hive2://localhost:10000
```

If everything works, you will see:

```
0: jdbc:hive2://localhost:10000>
```

You're ready to execute SQL.

---

## 📘 Demo 1 — Create Database + Tables (External + Managed)

```sql
SET hive.metastore.warehouse.dir=/opt/hive/warehouse;
```

```sql
CREATE DATABASE training_demo;
USE training_demo;
```

### Create EXTERNAL table

```sql
CREATE EXTERNAL TABLE customers (
  id INT,
  name STRING,
  country STRING,
  age INT
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/opt/hive/warehouse/customers';
```

### Create MANAGED table

```sql
CREATE TABLE transactions (
  txn_id INT,
  customer_id INT,
  amount DOUBLE,
  category STRING,
  date STRING
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ',';
```

---

## 📥 Loading Demo Data

Inside the container:

```bash
mkdir -p /opt/hive/data/customers
mkdir -p /opt/hive/data/transactions
```

Create sample files:

```bash
echo "1,Alice,FR,29
2,Bob,US,41
3,Mehdi,MA,35
4,Sara,FR,23
5,John,UK,52" > /opt/hive/data/customers/customers.csv
```

```bash
echo "1001,1,120,Electronics,2024-01-02
1002,1,30,Food,2024-01-05
1003,2,200,Travel,2024-02-10
1004,3,15,Food,2024-02-12
1005,3,80,Books,2024-02-15
1006,4,10,Food,2024-03-01
1007,5,150,Clothes,2024-03-02" > /opt/hive/data/transactions.csv
```

Load into Hive:

```sql
LOAD DATA LOCAL INPATH '/opt/hive/data/transactions.csv'
INTO TABLE transactions;
```

---

## 🔍 Verifying Data

```sql
SELECT * FROM customers;
SELECT * FROM transactions;
```

---

## 🛑 Stopping the Environment

```bash
docker-compose down
```

Remove volumes:

```bash
docker-compose down -v
```

---

## 🧩 Trainer Notes

- This demo is intentionally lightweight for fast execution.
- Excellent for:
  - SQL training
  - External vs managed table concepts
  - ETL workflows using `LOAD DATA`
- For a **real Hive-on-Hadoop cluster**, use the full version.

---

If you want the **full Hive demo pack** (data + SQL scripts + exercises), ask:
**"Generate the full Hive pack"**
